# Autonomous Crypto Trading Loop (codename: TBD)

Funding-carry core + alpha factory. Deterministic money path; LLMs only in `/meta`.
Verification is the edge. No real capital until `truth/LIVE_GATE.md` gate 1 passes.

## Layout
- `core/`  deterministic money path (may NOT import `meta/` — enforced by `tools/check_core_purity.py`)
- `meta/`  LLM layer (regime, recalibration, incident triage)
- `truth/` invariants, risk limits, schema, validation battery, live gate
- `scripts/setup_worktrees.sh`  one worktree per process (LCC/RCC/CX build)

## Verify
    python tools/check_core_purity.py
    pytest -q

## Sprints: see truth/SPEC.md (S0 done = this scaffold)
