"""Read-only market-data via ccxt (public endpoints). NOT live-validated in sandbox."""
from __future__ import annotations
from typing import Protocol

class DataClient(Protocol):
    def funding_bps(self, asset: str, ts: str) -> float: ...
    def ohlcv(self, asset: str, timeframe: str, limit: int) -> list: ...
    def open_interest(self, asset: str) -> float: ...

class CcxtReadOnly:
    SYMBOL = {"BTC": "BTC/USDT", "ETH": "ETH/USDT"}
    def __init__(self, venue: str):
        import ccxt
        self.venue = venue
        self.ex = getattr(ccxt, venue)({"enableRateLimit": True})
    def ohlcv(self, asset, timeframe="1h", limit=720):
        return self.ex.fetch_ohlcv(self.SYMBOL[asset], timeframe=timeframe, limit=limit)
    def funding_bps(self, asset, ts):
        fr = self.ex.fetch_funding_rate(self.SYMBOL[asset] + ":USDT")
        return float(fr.get("fundingRate") or 0.0) * 1e4
    def open_interest(self, asset):
        oi = self.ex.fetch_open_interest(self.SYMBOL[asset] + ":USDT")
        return float(oi.get("openInterestValue") or 0.0)
