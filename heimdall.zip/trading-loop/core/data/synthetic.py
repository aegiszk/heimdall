"""Offline synthetic market with an embedded funding-carry edge, for testing the pipeline."""
from __future__ import annotations
import numpy as np, pandas as pd
def make_market(T=800, seed=0, carry_edge=True):
    rng = np.random.default_rng(seed)
    ret = rng.normal(0, 0.012, T)                       # market returns (no free directional edge)
    fmean = 0.0003 if carry_edge else 0.0                # ~3bps/period positive funding
    funding = rng.normal(fmean, 0.00015, T)
    basis_noise = rng.normal(0, 0.0006, T)               # execution/basis noise on the carry leg
    oi = rng.uniform(0, 100, T)
    return pd.DataFrame({"ret": ret, "funding": funding, "basis_noise": basis_noise, "oi_pct": oi})
