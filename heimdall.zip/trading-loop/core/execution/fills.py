"""Realistic paper fills: slippage grows with size/liquidity; funding accrues on perp leg."""
from __future__ import annotations
def slippage_bps(qty: float, adv: float, base_bps=1.0, impact_k=50.0) -> float:
    return base_bps + impact_k * (qty / max(adv, 1e-9))
def fill_price(mid: float, side: str, qty: float, adv: float) -> float:
    slip = slippage_bps(qty, adv) / 1e4
    return mid * (1 + slip) if side == "buy" else mid * (1 - slip)
def funding_accrual(notional: float, funding_rate: float, periods: int) -> float:
    return notional * funding_rate * periods
