"""Gate = AND of the whole battery (truth/VALIDATION_BATTERY.md). Deterministic. No /meta."""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
from core.validation import metrics as m

@dataclass
class GateResult:
    passed: bool
    reasons: list = field(default_factory=list)     # which gates failed
    dsr: float | None = None; pbo: float | None = None; mc_p: float | None = None
    boot_lo: float | None = None; nw_t: float | None = None; max_dd: float | None = None
    n_trades: int | None = None; n_params: int | None = None; wf_min: float | None = None

def run_gate(returns, cfg, nb_trials, sr_trials_var, *, positions=None, market_returns=None,
             candidate_matrix=None, n_params=1) -> GateResult:
    r = np.asarray(returns, float)
    dsr = m.deflated_sharpe_ratio(r, sr_trials_var, nb_trials)
    nw = m.newey_west_tstat(r)
    boot_lo, _ = m.bootstrap_sharpe_ci(r)
    mdd = m.max_drawdown(r)
    wf = m.walk_forward(r, cfg["wf_splits"]); wf_min = min(wf) if wf else 0.0
    n_tr = len(r)
    pbo = m.cscv_pbo(candidate_matrix, cfg["pbo_S"]) if candidate_matrix is not None else None
    mc = (m.monte_carlo_permutation(positions, market_returns)
          if positions is not None and market_returns is not None else None)
    reasons = []
    def chk(name, ok):
        if not ok: reasons.append(name)
        return ok
    passed = all([
        chk("dsr", dsr > cfg["dsr_min"]),
        chk("nw_t", nw > cfg["nw_t_min"]),
        chk("boot_lo", boot_lo > cfg["boot_lo_min"]),
        chk("max_dd", mdd > -cfg["max_dd_max"]),
        chk("min_trades", n_tr >= cfg["min_trades"]),
        chk("max_params", n_params <= cfg["max_params"]),
        chk("wf_min", wf_min > cfg["wf_min_sharpe"]),
        chk("pbo", pbo is None or pbo < cfg["pbo_max"]),
        chk("mc", mc is None or mc < cfg["mc_p_max"]),
    ])
    return GateResult(passed, reasons, dsr, pbo, mc, boot_lo, nw, mdd, n_tr, n_params, wf_min)
